# 4teen-ambassador-system — SITE INTEGRATION

Generated: 2026-04-01T09:02:44.455Z
Repository: info14fourteen-creator/4teen-ambassador-system
Branch: main

## Included files

- 4teen-ambassador-system :: apps/site-integration/src/ambassador/autoMount.ts
- 4teen-ambassador-system :: apps/site-integration/src/ambassador/hash.ts
- 4teen-ambassador-system :: apps/site-integration/src/ambassador/register.ts
- 4teen-ambassador-system :: apps/site-integration/src/ambassador/widget.ts
- 4teen-ambassador-system :: apps/site-integration/src/purchase/afterBuy.ts
- 4teen-ambassador-system :: apps/site-integration/src/purchase/submitAttribution.ts
- 4teen-ambassador-system :: apps/site-integration/src/referral/capture.ts
- 4teen-ambassador-system :: apps/site-integration/src/referral/firstTouch.ts
- 4teen-ambassador-system :: apps/site-integration/src/referral/storage.ts

---

## FILE: 4teen-ambassador-system :: apps/site-integration/src/ambassador/autoMount.ts

```ts
import { mountAmbassadorWidget } from "./widget";

export interface AutoMountAmbassadorWidgetsOptions {
  backendBaseUrl: string;
  selector?: string;
}

const DEFAULT_SELECTOR = '[data-fourteen-ambassador-widget="register"]';

function assertNonEmpty(value: string, fieldName: string): string {
  const normalized = String(value || "").trim();

  if (!normalized) {
    throw new Error(`${fieldName} is required`);
  }

  return normalized;
}

function isHTMLElement(value: Element | null): value is HTMLElement {
  return value instanceof HTMLElement;
}

function readOptionalAttr(
  element: HTMLElement,
  name: string
): string | undefined {
  const value = element.getAttribute(name);

  if (value == null) {
    return undefined;
  }

  const normalized = value.trim();
  return normalized || undefined;
}

export function autoMountAmbassadorWidgets(
  options: AutoMountAmbassadorWidgetsOptions
): void {
  const backendBaseUrl = assertNonEmpty(options.backendBaseUrl, "backendBaseUrl");
  const selector = options.selector || DEFAULT_SELECTOR;

  const elements = Array.from(document.querySelectorAll(selector));

  for (const element of elements) {
    if (!isHTMLElement(element)) {
      continue;
    }

    if (element.dataset.fourteenAmbassadorMounted === "true") {
      continue;
    }

    mountAmbassadorWidget({
      target: element,
      backendBaseUrl,
      defaultSlug: readOptionalAttr(element, "data-default-slug"),
      defaultMeta: readOptionalAttr(element, "data-default-meta"),
      title: readOptionalAttr(element, "data-title"),
      description: readOptionalAttr(element, "data-description")
    });

    element.dataset.fourteenAmbassadorMounted = "true";
  }
}

export function autoMountAmbassadorWidgetsOnReady(
  options: AutoMountAmbassadorWidgetsOptions
): void {
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", () => {
      autoMountAmbassadorWidgets(options);
    });
    return;
  }

  autoMountAmbassadorWidgets(options);
}
```

---

## FILE: 4teen-ambassador-system :: apps/site-integration/src/ambassador/hash.ts

```ts
import { keccak_256 } from "@noble/hashes/sha3";
import { utf8ToBytes } from "@noble/hashes/utils";

export const ZERO_BYTES32 =
  "0x0000000000000000000000000000000000000000000000000000000000000000";

export interface BuildAmbassadorRegistrationHashesInput {
  slug: string;
}

export interface AmbassadorRegistrationHashes {
  slug: string;
  slugHash: string;
  metaHash: string;
}

function assertNonEmpty(value: string, fieldName: string): string {
  const normalized = String(value || "").trim();

  if (!normalized) {
    throw new Error(`${fieldName} is required`);
  }

  return normalized;
}

export function normalizeSlug(value: string): string {
  return assertNonEmpty(value, "slug")
    .toLowerCase()
    .replace(/[^a-z0-9_-]/g, "");
}

function bytesToHex(bytes: Uint8Array): string {
  return Array.from(bytes, (byte) => byte.toString(16).padStart(2, "0")).join("");
}

export function keccakUtf8ToHex(value: string): string {
  const bytes = utf8ToBytes(String(value || ""));
  return `0x${bytesToHex(keccak_256(bytes))}`;
}

export function buildAmbassadorRegistrationHashes(
  input: BuildAmbassadorRegistrationHashesInput
): AmbassadorRegistrationHashes {
  const slug = normalizeSlug(input.slug);

  if (!slug) {
    throw new Error("slug is required");
  }

  return {
    slug,
    slugHash: keccakUtf8ToHex(slug),
    metaHash: ZERO_BYTES32
  };
}
```

---

## FILE: 4teen-ambassador-system :: apps/site-integration/src/ambassador/register.ts

```ts
import { FOURTEEN_CONTROLLER_CONTRACT } from "../../../../shared/config/contracts";
import { buildAmbassadorRegistrationHashes } from "./hash";

declare global {
  interface Window {
    tronWeb?: any;
    tronLink?: any;
  }
}

export interface AmbassadorRegistrationResult {
  slug: string;
  slugHash: string;
  metaHash: string;
  txid: string;
  referralLink: string;
}

export interface RegisterAmbassadorInput {
  slug: string;
  backendBaseUrl: string;
}

function assertNonEmpty(value: string, fieldName: string): string {
  const normalized = String(value || "").trim();

  if (!normalized) {
    throw new Error(`${fieldName} is required`);
  }

  return normalized;
}

async function getTronWeb(): Promise<any> {
  const tronWeb = window.tronWeb;

  if (!tronWeb || !tronWeb.defaultAddress?.base58) {
    throw new Error("Tron wallet is not connected");
  }

  return tronWeb;
}

async function getConnectedWallet(): Promise<string> {
  const tronWeb = await getTronWeb();
  return assertNonEmpty(tronWeb.defaultAddress.base58, "wallet");
}

async function getControllerContract(): Promise<any> {
  const tronWeb = await getTronWeb();
  return tronWeb.contract().at(FOURTEEN_CONTROLLER_CONTRACT);
}

function normalizeBaseUrl(value: string): string {
  return assertNonEmpty(value, "backendBaseUrl").replace(/\/+$/, "");
}

async function ensureSlugAvailable(
  backendBaseUrl: string,
  slug: string
): Promise<void> {
  const response = await fetch(
    `${normalizeBaseUrl(backendBaseUrl)}/slug/check?slug=${encodeURIComponent(slug)}`,
    {
      method: "GET",
      headers: {
        "Content-Type": "application/json"
      }
    }
  );

  const payload = await response.json();

  if (!response.ok || !payload?.ok) {
    throw new Error(payload?.error || "Failed to check slug availability");
  }

  if (!payload.available) {
    throw new Error("Slug is already taken");
  }
}

async function completeRegistration(
  backendBaseUrl: string,
  input: {
    slug: string;
    slugHash: string;
    wallet: string;
  }
): Promise<{ referralLink: string }> {
  const response = await fetch(
    `${normalizeBaseUrl(backendBaseUrl)}/ambassador/register-complete`,
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(input)
    }
  );

  const payload = await response.json();

  if (!response.ok || !payload?.ok) {
    throw new Error(payload?.error || "Failed to complete ambassador registration");
  }

  return {
    referralLink: assertNonEmpty(payload.result?.referralLink, "referralLink")
  };
}

export async function registerAmbassador(
  input: RegisterAmbassadorInput
): Promise<AmbassadorRegistrationResult> {
  const backendBaseUrl = normalizeBaseUrl(input.backendBaseUrl);
  const wallet = await getConnectedWallet();

  const hashes = buildAmbassadorRegistrationHashes({
    slug: input.slug
  });

  await ensureSlugAvailable(backendBaseUrl, hashes.slug);

  const contract = await getControllerContract();
  const txid = await contract
    .registerAsAmbassador(hashes.slugHash, hashes.metaHash)
    .send();

  const completed = await completeRegistration(backendBaseUrl, {
    slug: hashes.slug,
    slugHash: hashes.slugHash,
    wallet
  });

  return {
    slug: hashes.slug,
    slugHash: hashes.slugHash,
    metaHash: hashes.metaHash,
    txid: assertNonEmpty(txid, "txid"),
    referralLink: completed.referralLink
  };
}
```

---

## FILE: 4teen-ambassador-system :: apps/site-integration/src/ambassador/widget.ts

```ts
import { registerAmbassador } from "./register";

export interface MountAmbassadorWidgetOptions {
  target: HTMLElement;
  backendBaseUrl: string;
  defaultSlug?: string;
  title?: string;
  description?: string;
}

interface WidgetState {
  isSubmitting: boolean;
  error: string | null;
  success: {
    slug: string;
    referralLink: string;
    txid: string;
  } | null;
}

function assertElement(target: HTMLElement | null | undefined): HTMLElement {
  if (!target) {
    throw new Error("target element is required");
  }

  return target;
}

function assertNonEmpty(value: string, fieldName: string): string {
  const normalized = String(value || "").trim();

  if (!normalized) {
    throw new Error(`${fieldName} is required`);
  }

  return normalized;
}

function createEl<K extends keyof HTMLElementTagNameMap>(
  tag: K,
  className?: string,
  text?: string
): HTMLElementTagNameMap[K] {
  const el = document.createElement(tag);

  if (className) {
    el.className = className;
  }

  if (text) {
    el.textContent = text;
  }

  return el;
}

function setButtonBusy(button: HTMLButtonElement, busy: boolean): void {
  button.disabled = busy;
  button.textContent = busy ? "Registering..." : "Register Ambassador";
}

function normalizeReferralLink(link: string): string {
  return assertNonEmpty(link, "referralLink");
}

function buildAbsoluteReferralLink(relativeOrAbsoluteLink: string): string {
  const normalized = normalizeReferralLink(relativeOrAbsoluteLink);

  if (/^https?:\/\//i.test(normalized)) {
    return normalized;
  }

  return `${window.location.origin}${normalized.startsWith("/") ? normalized : `/${normalized}`}`;
}

export function mountAmbassadorWidget(
  options: MountAmbassadorWidgetOptions
): void {
  const target = assertElement(options.target);

  const state: WidgetState = {
    isSubmitting: false,
    error: null,
    success: null
  };

  const root = createEl(
    "div",
    "fourteen-ambassador-widget rounded-2xl border border-white/10 bg-white/5 p-5"
  );

  const header = createEl("div", "fourteen-ambassador-widget__header");
  const title = createEl(
    "h2",
    "fourteen-ambassador-widget__title text-xl font-semibold",
    options.title || "Become an ambassador"
  );
  const description = createEl(
    "p",
    "fourteen-ambassador-widget__description mt-2 text-sm opacity-80",
    options.description ||
      "Choose your public referral slug, register on-chain, and receive your referral link."
  );

  header.appendChild(title);
  header.appendChild(description);

  const form = createEl("form", "fourteen-ambassador-widget__form mt-4") as HTMLFormElement;

  const slugLabel = createEl("label", "fourteen-ambassador-widget__label block text-sm");
  slugLabel.textContent = "Referral slug";

  const slugInput = createEl(
    "input",
    "fourteen-ambassador-widget__input mt-2 w-full rounded-xl border border-white/10 bg-transparent px-3 py-3 outline-none"
  ) as HTMLInputElement;
  slugInput.type = "text";
  slugInput.name = "slug";
  slugInput.placeholder = "stan";
  slugInput.autocomplete = "off";
  slugInput.value = options.defaultSlug || "";

  const submitButton = createEl(
    "button",
    "fourteen-ambassador-widget__submit mt-4 rounded-2xl px-4 py-3 font-semibold"
  ) as HTMLButtonElement;
  submitButton.type = "submit";
  submitButton.textContent = "Register Ambassador";

  const messageBox = createEl("div", "fourteen-ambassador-widget__message mt-4 text-sm");
  const successBox = createEl("div", "fourteen-ambassador-widget__success mt-4");
  successBox.style.display = "none";

  const successTitle = createEl(
    "div",
    "fourteen-ambassador-widget__success-title text-sm font-semibold",
    "Registration completed"
  );

  const successSlug = createEl("div", "fourteen-ambassador-widget__success-slug mt-2 text-sm");
  const successLinkWrap = createEl("div", "fourteen-ambassador-widget__success-link mt-2 text-sm");
  const successLink = createEl("a", "underline") as HTMLAnchorElement;
  successLink.target = "_blank";
  successLink.rel = "noreferrer";

  const successTx = createEl("div", "fourteen-ambassador-widget__success-tx mt-2 text-xs opacity-80");

  successLinkWrap.appendChild(successLink);
  successBox.appendChild(successTitle);
  successBox.appendChild(successSlug);
  successBox.appendChild(successLinkWrap);
  successBox.appendChild(successTx);

  function render(): void {
    setButtonBusy(submitButton, state.isSubmitting);

    if (state.error) {
      messageBox.textContent = state.error;
      messageBox.style.display = "block";
    } else {
      messageBox.textContent = "";
      messageBox.style.display = "none";
    }

    if (state.success) {
      const absoluteLink = buildAbsoluteReferralLink(state.success.referralLink);

      successSlug.textContent = `Slug: ${state.success.slug}`;
      successLink.href = absoluteLink;
      successLink.textContent = absoluteLink;
      successTx.textContent = `Tx: ${state.success.txid}`;
      successBox.style.display = "block";
    } else {
      successBox.style.display = "none";
    }
  }

  form.addEventListener("submit", async (event) => {
    event.preventDefault();

    if (state.isSubmitting) {
      return;
    }

    state.isSubmitting = true;
    state.error = null;
    state.success = null;
    render();

    try {
      const result = await registerAmbassador({
        slug: slugInput.value,
        backendBaseUrl: options.backendBaseUrl
      });

      state.success = {
        slug: result.slug,
        referralLink: result.referralLink,
        txid: result.txid
      };
    } catch (error) {
      state.error =
        error && typeof error === "object" && "message" in error
          ? String((error as { message?: unknown }).message || "").trim() || "Registration failed"
          : typeof error === "string" && error.trim()
            ? error.trim()
            : "Registration failed";
    } finally {
      state.isSubmitting = false;
      render();
    }
  });

  slugLabel.appendChild(slugInput);

  form.appendChild(slugLabel);
  form.appendChild(submitButton);

  root.appendChild(header);
  root.appendChild(form);
  root.appendChild(messageBox);
  root.appendChild(successBox);

  target.innerHTML = "";
  target.appendChild(root);

  render();
}
```

---

## FILE: 4teen-ambassador-system :: apps/site-integration/src/purchase/afterBuy.ts

```ts
import { getStoredReferral } from "../referral/storage";
import {
  submitAttribution,
  SubmitAttributionOptions,
  SubmitAttributionResponse
} from "./submitAttribution";

export interface AfterBuyInput {
  txHash: string;
  buyerWallet: string;
}

export interface AfterBuyOptions extends SubmitAttributionOptions {
  now?: number;
}

export interface AfterBuyResult<T = unknown> {
  status: "submitted" | "skipped-no-referral";
  referralSlug: string | null;
  response: SubmitAttributionResponse<T> | null;
}

function assertNonEmpty(value: string, fieldName: string): string {
  const normalized = String(value || "").trim();

  if (!normalized) {
    throw new Error(`${fieldName} is required`);
  }

  return normalized;
}

export async function handleAfterBuy<T = unknown>(
  input: AfterBuyInput,
  options: AfterBuyOptions
): Promise<AfterBuyResult<T>> {
  const txHash = assertNonEmpty(input.txHash, "txHash");
  const buyerWallet = assertNonEmpty(input.buyerWallet, "buyerWallet");
  const now = options.now ?? Date.now();

  const referral = getStoredReferral(now);

  if (!referral) {
    return {
      status: "skipped-no-referral",
      referralSlug: null,
      response: null
    };
  }

  const response = await submitAttribution<T>(
    {
      txHash,
      buyerWallet,
      slug: referral.slug
    },
    options
  );

  return {
    status: "submitted",
    referralSlug: referral.slug,
    response
  };
}
```

---

## FILE: 4teen-ambassador-system :: apps/site-integration/src/purchase/submitAttribution.ts

```ts
import { assertValidSlug, normalizeSlug } from "../../../../shared/utils/slug";

export interface AttributionPayload {
  txHash: string;
  buyerWallet: string;
  slug: string;
}

export interface SubmitAttributionOptions {
  endpoint: string;
  signal?: AbortSignal;
  headers?: Record<string, string>;
  fetchImpl?: typeof fetch;
}

export interface SubmitAttributionResponse<T = unknown> {
  ok: boolean;
  status: number;
  data: T | null;
}

function assertNonEmpty(value: string, fieldName: string): string {
  const normalized = String(value || "").trim();

  if (!normalized) {
    throw new Error(`${fieldName} is required`);
  }

  return normalized;
}

function normalizeEndpoint(endpoint: string): string {
  return assertNonEmpty(endpoint, "endpoint").replace(/\/+$/, "");
}

function normalizeWallet(wallet: string): string {
  return assertNonEmpty(wallet, "buyerWallet");
}

function normalizeTxHash(txHash: string): string {
  return assertNonEmpty(txHash, "txHash");
}

function normalizeAttributionSlug(slug: string): string {
  return assertValidSlug(normalizeSlug(assertNonEmpty(slug, "slug")));
}

async function parseResponseBody<T>(response: Response): Promise<T | null> {
  const responseText = await response.text();

  if (!responseText) {
    return null;
  }

  try {
    return JSON.parse(responseText) as T;
  } catch {
    return null;
  }
}

function extractErrorMessage(data: unknown, status: number): string {
  if (
    data &&
    typeof data === "object" &&
    "error" in data &&
    typeof (data as { error?: unknown }).error === "string" &&
    (data as { error: string }).error.trim()
  ) {
    return (data as { error: string }).error.trim();
  }

  return `Attribution request failed with status ${status}`;
}

export async function submitAttribution<T = unknown>(
  payload: AttributionPayload,
  options: SubmitAttributionOptions
): Promise<SubmitAttributionResponse<T>> {
  const endpoint = normalizeEndpoint(options.endpoint);
  const txHash = normalizeTxHash(payload.txHash);
  const buyerWallet = normalizeWallet(payload.buyerWallet);
  const slug = normalizeAttributionSlug(payload.slug);

  const fetchImpl = options.fetchImpl ?? fetch;

  if (typeof fetchImpl !== "function") {
    throw new Error("Fetch implementation is not available");
  }

  const response = await fetchImpl(endpoint, {
    method: "POST",
    signal: options.signal,
    headers: {
      "content-type": "application/json",
      ...(options.headers ?? {})
    },
    body: JSON.stringify({
      txHash,
      buyerWallet,
      slug
    })
  });

  const data = await parseResponseBody<T>(response);

  if (!response.ok) {
    throw new Error(extractErrorMessage(data, response.status));
  }

  return {
    ok: true,
    status: response.status,
    data
  };
}
```

---

## FILE: 4teen-ambassador-system :: apps/site-integration/src/referral/capture.ts

```ts
import {
  REFERRAL_QUERY_PARAM,
  REFERRAL_TTL_MS
} from "../../../../shared/config/referral";
import { isValidSlug, normalizeSlug } from "../../../../shared/utils/slug";
import { StoredReferralRecord, getStoredReferral } from "./storage";
import { applyFirstTouch, ApplyFirstTouchResult } from "./firstTouch";

export interface CaptureReferralOptions {
  search?: string;
  ttlMs?: number;
  now?: number;
}

export interface CaptureReferralResult {
  foundSlug: string | null;
  applied: ApplyFirstTouchResult | null;
  activeReferral: StoredReferralRecord | null;
}

export function readReferralSlugFromSearch(search?: string): string | null {
  const rawSearch =
    typeof search === "string"
      ? search
      : typeof window !== "undefined"
        ? window.location.search
        : "";

  const params = new URLSearchParams(rawSearch);
  const rawSlug = params.get(REFERRAL_QUERY_PARAM);

  if (!rawSlug) {
    return null;
  }

  const normalized = normalizeSlug(rawSlug);

  if (!isValidSlug(normalized)) {
    return null;
  }

  return normalized;
}

export function captureReferralFromUrl(
  options: CaptureReferralOptions = {}
): CaptureReferralResult {
  const now = options.now ?? Date.now();
  const ttlMs = options.ttlMs ?? REFERRAL_TTL_MS;

  const foundSlug = readReferralSlugFromSearch(options.search);

  if (!foundSlug) {
    return {
      foundSlug: null,
      applied: null,
      activeReferral: getStoredReferral(now)
    };
  }

  const applied = applyFirstTouch({
    slug: foundSlug,
    ttlMs,
    now
  });

  return {
    foundSlug,
    applied,
    activeReferral: applied.record
  };
}
```

---

## FILE: 4teen-ambassador-system :: apps/site-integration/src/referral/firstTouch.ts

```ts
import { REFERRAL_TTL_MS } from "../../../../shared/config/referral";
import {
  StoredReferralRecord,
  getStoredReferral,
  saveReferral
} from "./storage";
import { assertValidSlug, normalizeSlug } from "../../../../shared/utils/slug";

export interface ApplyFirstTouchInput {
  slug: string;
  ttlMs?: number;
  now?: number;
}

export interface ApplyFirstTouchResult {
  status: "stored" | "kept-existing";
  record: StoredReferralRecord;
}

export function applyFirstTouch(
  input: ApplyFirstTouchInput
): ApplyFirstTouchResult {
  const now = input.now ?? Date.now();
  const ttlMs = input.ttlMs ?? REFERRAL_TTL_MS;
  const incomingSlug = assertValidSlug(normalizeSlug(input.slug));

  const existing = getStoredReferral(now);

  if (existing) {
    return {
      status: "kept-existing",
      record: existing
    };
  }

  const record = saveReferral({
    slug: incomingSlug,
    now,
    ttlMs
  });

  return {
    status: "stored",
    record
  };
}
```

---

## FILE: 4teen-ambassador-system :: apps/site-integration/src/referral/storage.ts

```ts
import {
  REFERRAL_STORAGE_KEY,
  REFERRAL_TTL_MS
} from "../../../../shared/config/referral";
import { assertValidSlug, normalizeSlug } from "../../../../shared/utils/slug";

export interface StoredReferralRecord {
  slug: string;
  capturedAt: number;
  expiresAt: number;
  source: "query";
}

export interface SaveReferralInput {
  slug: string;
  now?: number;
  ttlMs?: number;
}

function isBrowser(): boolean {
  return typeof window !== "undefined" && typeof window.localStorage !== "undefined";
}

function safeParseRecord(raw: string | null): StoredReferralRecord | null {
  if (!raw) {
    return null;
  }

  try {
    const parsed = JSON.parse(raw) as Partial<StoredReferralRecord>;

    if (!parsed || typeof parsed !== "object") return null;
    if (typeof parsed.slug !== "string") return null;
    if (typeof parsed.capturedAt !== "number") return null;
    if (typeof parsed.expiresAt !== "number") return null;
    if (parsed.source !== "query") return null;

    const normalizedSlug = normalizeSlug(parsed.slug);
    const safeSlug = assertValidSlug(normalizedSlug);

    return {
      slug: safeSlug,
      capturedAt: parsed.capturedAt,
      expiresAt: parsed.expiresAt,
      source: "query"
    };
  } catch {
    return null;
  }
}

export function getStoredReferralRaw(): StoredReferralRecord | null {
  if (!isBrowser()) {
    return null;
  }

  const raw = window.localStorage.getItem(REFERRAL_STORAGE_KEY);
  return safeParseRecord(raw);
}

export function isReferralExpired(
  record: StoredReferralRecord,
  now = Date.now()
): boolean {
  return record.expiresAt <= now;
}

export function getStoredReferral(now = Date.now()): StoredReferralRecord | null {
  const record = getStoredReferralRaw();

  if (!record) {
    return null;
  }

  if (isReferralExpired(record, now)) {
    clearStoredReferral();
    return null;
  }

  return record;
}

export function saveReferral(input: SaveReferralInput): StoredReferralRecord {
  if (!isBrowser()) {
    throw new Error("Referral storage is only available in the browser");
  }

  const now = input.now ?? Date.now();
  const ttlMs = input.ttlMs ?? REFERRAL_TTL_MS;
  const slug = assertValidSlug(normalizeSlug(input.slug));

  if (ttlMs <= 0) {
    throw new Error("Referral TTL must be greater than zero");
  }

  const record: StoredReferralRecord = {
    slug,
    capturedAt: now,
    expiresAt: now + ttlMs,
    source: "query"
  };

  window.localStorage.setItem(REFERRAL_STORAGE_KEY, JSON.stringify(record));

  return record;
}

export function clearStoredReferral(): void {
  if (!isBrowser()) {
    return;
  }

  window.localStorage.removeItem(REFERRAL_STORAGE_KEY);
}
```
